216 WebSafe Colors Chromatic DHTML Color Picker
        Free-Color-Picker.com

    *********************************
    *                               *
    *   Complete Instuctions Can    *
    *   Be Found In Readme.Html     *
    *                               *
    *********************************

This zipped file contains the following files:

    1. readme.html          { INSTRUCTIONS! }
    2. 201a.js              { main javascript code }
    3. license.txt          { important license information }
    4. style.css/sel.gif/free-color-picker-logo.jpg
    					    { files needed for readme.html }
    5. readme.txt           { this file }
    
If any of these files are missing, please re-download
them from the approved download site at:

http://www.free-color-picker.com